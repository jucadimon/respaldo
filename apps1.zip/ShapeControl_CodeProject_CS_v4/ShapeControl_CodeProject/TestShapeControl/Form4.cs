﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace TestShapeControl
{
    public partial class Form4 : Form
    {
        double theta =Math.PI/10;
        double theta2 = 0;
        bool bReadyToAutoSwitchPhoto = false;

        int photoNo = 0;
        int maxNumPhoto = 8;

        int x0 = 0;
        int y0 = 0;
        int dist = 0;
        int dist2 = 0;
        public Form4()
        {
            InitializeComponent();
            nextPhoto();
           // this.Size = shape1.Size;
            shape1.Left = 0;
            shape1.Top = 0;
            shape1.Text = "\n\n\n\n\n\n\n\nLeft Click: Start/Stop\nRight Click: Next Photo\nDbl Click: Close";
            x0 = shape1.Left + shape1.Width / 2;
            y0 = shape1.Top + shape1.Height / 2;
            
            dist = line1.Width - 2*line1.BorderWidth;
            dist2 = line2.Width - 2 * line2.BorderWidth;

            int x1 = (int)(dist * Math.Cos(theta) + x0);
            int y1 = (int)(dist * Math.Sin(theta) + y0);
            ShapeControl.Line.setLine(ref line1, x0, y0, x1, y1);

            int x2 = (int)(dist2 * Math.Cos(theta2) + x0);
            int y2 = (int)(dist2 * Math.Sin(theta2) + y0);
            ShapeControl.Line.setLine(ref line2, x2, y2, x0, y0);
            this.panel1.Region = shape1.Region;


            this.Region = shape1.Region;
     
        }



        private double RadianToDegree(double angle)
        {
            return angle * (180.0 / Math.PI);
        }  

        private void timer1_Tick(object sender, EventArgs e)
        {
 
            theta += (Math.PI / 180.0)/3.0;
            if (theta>(2*Math.PI)) theta -=(2.0*Math.PI);

            int x1 = (int)(dist * Math.Cos(theta) + x0);
            int y1 = (int)(dist * Math.Sin(theta) + y0);
            ShapeControl.Line.setLine(ref line1, x0, y0, x1, y1);

            double mindelta =2;
            double maxdelta=178;

            int deltaangle = (int)(RadianToDegree(theta) - RadianToDegree(theta2));
            if (deltaangle < 0) deltaangle += 180;
            if(bReadyToAutoSwitchPhoto)
                if (deltaangle< mindelta)
                {
                    nextPhoto();
                    bReadyToAutoSwitchPhoto = false;
                }

            if (deltaangle  > maxdelta)
            {
                bReadyToAutoSwitchPhoto = true;
            }


        }



        private void shape1_Click(object sender, EventArgs e)
        {
            
            timer1.Enabled = !timer1.Enabled;
            timer2.Enabled = !timer2.Enabled;
        }



        private void timer2_Tick(object sender, EventArgs e)
        {
            theta2 -= (Math.PI / 180.0)/2.5;
       
           // if (theta2 > (2 * Math.PI)) theta2 -= (2 * Math.PI);
            if (theta2 < 0) theta2 += (2.0 * Math.PI);
            int x2 = (int)(dist2 * Math.Cos(theta2) + x0);
            int y2 = (int)(dist2 * Math.Sin(theta2) + y0);
            ShapeControl.Line.setLine(ref line2, x2, y2, x0, y0);

        }



        private void nextPhoto()
        {


            object o=global::TestShapeControl.Properties.Resources.ResourceManager.GetObject("photo" + photoNo);
            panel1.BackgroundImage = (Bitmap)o;
            photoNo = (++photoNo) % maxNumPhoto;
        }

        private void shape1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Clicks >1) return;
            if (e.Button == MouseButtons.Left)
                shape1_Click(null, null);
            if (e.Button == MouseButtons.Right)
                nextPhoto();
        }

        private void shape1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
               this.Close();
        }




    }
}
