﻿namespace TestShapeControl
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.line2 = new ShapeControl.CustomControl1();
            this.line1 = new ShapeControl.CustomControl1();
            this.shape1 = new ShapeControl.CustomControl1();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Controls.Add(this.line2);
            this.panel1.Controls.Add(this.line1);
            this.panel1.Controls.Add(this.shape1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(584, 496);
            this.panel1.TabIndex = 13;
            // 
            // line2
            // 
            this.line2.AnimateBorder = false;
            this.line2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.line2.Blink = false;
            this.line2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.line2.BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.line2.BorderWidth = 41;
            this.line2.CenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.line2.Connector = ShapeControl.ConnecterType.Center;
            this.line2.Direction = ShapeControl.LineDirection.None;
            this.line2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.line2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.line2.Location = new System.Drawing.Point(100, 199);
            this.line2.Name = "line2";
            this.line2.Shape = ShapeControl.ShapeType.LineHorizontal;
            this.line2.ShapeImage = null;
            this.line2.Size = new System.Drawing.Size(270, 86);
            this.line2.SurroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.line2.TabIndex = 14;
            this.line2.Tag2 = "";
            this.line2.Text = "customControl11";
            this.line2.UseGradient = false;
            this.line2.Vibrate = false;
            // 
            // line1
            // 
            this.line1.AnimateBorder = false;
            this.line1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.line1.Blink = false;
            this.line1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(61)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.line1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.line1.BorderWidth = 41;
            this.line1.CenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.line1.Connector = ShapeControl.ConnecterType.Center;
            this.line1.Direction = ShapeControl.LineDirection.LeftUp;
            this.line1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.line1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.line1.Location = new System.Drawing.Point(25, 213);
            this.line1.Name = "line1";
            this.line1.Shape = ShapeControl.ShapeType.LineHorizontal;
            this.line1.ShapeImage = null;
            this.line1.Size = new System.Drawing.Size(270, 86);
            this.line1.SurroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.line1.TabIndex = 15;
            this.line1.Tag2 = "";
            this.line1.Text = "line1";
            this.line1.UseGradient = false;
            this.line1.Vibrate = false;
            // 
            // shape1
            // 
            this.shape1.AnimateBorder = false;
            this.shape1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.shape1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.shape1.Blink = false;
            this.shape1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.shape1.BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.shape1.BorderWidth = 23;
            this.shape1.CenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.shape1.Connector = ShapeControl.ConnecterType.Center;
            this.shape1.Direction = ShapeControl.LineDirection.None;
            this.shape1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shape1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.shape1.Location = new System.Drawing.Point(0, 0);
            this.shape1.Name = "shape1";
            this.shape1.Shape = ShapeControl.ShapeType.Ellipse;
            this.shape1.ShapeImage = null;
            this.shape1.Size = new System.Drawing.Size(570, 485);
            this.shape1.SurroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(141)))), ((int)(((byte)(171)))), ((int)(((byte)(255)))));
            this.shape1.TabIndex = 16;
            this.shape1.Tag2 = "";
            this.shape1.UseGradient = true;
            this.shape1.Vibrate = false;
            this.shape1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.shape1_MouseDoubleClick);
            this.shape1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.shape1_MouseDown);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(611, 525);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Test Line";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Panel panel1;
        private ShapeControl.CustomControl1 line1;
        private ShapeControl.CustomControl1 line2;
        private ShapeControl.CustomControl1 shape1;

    }
}