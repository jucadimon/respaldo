﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestShapeControl
{
    public partial class Form4a : Form
    {
        string hints;
        string options;
        List<ShapeControl.CustomControl1> ctrllist;
        int num_correct = 0;
        int num_total = 8;
        int num_choosen = 0;

        public Form4a()
        {
            InitializeComponent();
            
            options = global::TestShapeControl.Properties.Resources.ResourceManager.GetString("Options");
            hints = global::TestShapeControl.Properties.Resources.ResourceManager.GetString("Hints");
            var vhints = hints.Split('|');
            var vInitials = vhints[0].Split(' ');
            var vNames = vhints[1].Split(';');

            var v=options.Split(' ');
            ctrllist=new List<ShapeControl.CustomControl1>();
            int sx = customControl11.Location.X;
            int sy = customControl11.Location.Y;
            int gapx=70,gapy=80;
            for (int i = 0; i < v.Length; i++)
            {
                ShapeControl.CustomControl1 ctrl1 = new ShapeControl.CustomControl1();
                ctrl1.Name ="ctrl_" +i;
                ctrl1.Shape = customControl11.Shape;
                if (customControl11.ShapeImage != null)
                    ctrl1.ShapeImage = customControl11.ShapeImage; 
                ctrl1.Size = customControl11.Size;
                ctrl1.BorderColor = customControl11.BorderColor;
                ctrl1.BackColor = customControl11.BackColor;
                ctrl1.BorderWidth = customControl11.BorderWidth;
                int x = sx + (i % 5) * (ctrl1.Width + gapx);
                int y = sy + (i / 5) * (ctrl1.Height + gapy);
                ctrl1.Location = new Point(x, y);
                Label lbl1 = new Label();
                lbl1.Name ="lbl_" + i;
                lbl1.AutoSize = true;
                lbl1.MaximumSize = new Size(ctrl1.Width , gapy - 20);
                lbl1.TextAlign = ContentAlignment.TopCenter;
                
               // lbl1.BackColor = Color.Blue;
                lbl1.Location = new Point(x, y + ctrl1.Height + 5);
              
                ctrl1.Text = v[i];
                ctrl1.Tag = "X"; //default no hit

                ctrl1.Visible = true;
                lbl1.Visible = false;

                ctrl1.MouseClick += new MouseEventHandler(ctrl1_MouseClick);
                for (int j = 0; j < vInitials.Length; j++)
                {
                    if (v[i].ToString() == vInitials[j])
                    {
                        ctrl1.Tag = ""+j; //store index of the answer
                        ctrl1.Tag2 = lbl1.Name;

                        lbl1.Tag = vNames[j];
                        lbl1.Text = lbl1.Tag.ToString();
                        break;
                    }

                }
                Controls.Add(ctrl1);
                ctrllist.Add(ctrl1);
                Controls.Add(lbl1);

            }
        }

        void ctrl1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                if (((ShapeControl.CustomControl1)sender).BorderWidth == 0)
                {
                    if (num_choosen < num_total)
                    {
                        ((ShapeControl.CustomControl1)sender).BorderWidth = 3;
                        num_choosen++;
                    }
                }
                else
                {
                    ((ShapeControl.CustomControl1)sender).BorderWidth = 0;
                    num_choosen--;
                }
                
            }
           // throw new NotImplementedException();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            for (int i = 0; i < ctrllist.Count; i++)
            {
                if (ctrllist[i].BorderWidth != 0) //choosen
                {
                    if (ctrllist[i].Tag.ToString() != "X")
                    {
                        num_correct++;
                        ctrllist[i].BackColor = Color.FromArgb(100, Color.LightGreen);
                        Control[] c = Controls.Find(ctrllist[i].Tag2.ToString(), false);
                        c[0].Visible = true;
                        string sindex=ctrllist[i].Tag.ToString();
                        ctrllist[i].BackgroundImageLayout = ImageLayout.Zoom;
                        ctrllist[i].BackgroundImage =
                            (Bitmap)global::TestShapeControl.Properties.Resources.ResourceManager.GetObject("photo" + sindex);


                    }
                    else
                    {
                        ctrllist[i].BackColor = Color.FromArgb(90, Color.Red); 
                    }
                }


            }
            if (num_correct == num_total)
                label1.Text = "Congratulations, all correct, you rock!";
            else
                label1.Text = num_correct + " of " + num_total + " correct..";
            button1.Visible = false;
            
        }
    }
}
