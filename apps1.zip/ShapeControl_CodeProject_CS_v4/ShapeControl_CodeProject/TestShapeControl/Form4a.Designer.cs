﻿namespace TestShapeControl
{
    partial class Form4a
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.customControl11 = new ShapeControl.CustomControl1();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(669, 499);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 499);
            this.label1.MaximumSize = new System.Drawing.Size(650, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(584, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Click on the initials of all 8 of the personalities that you have recognized and " +
                "then submit your answer";
            // 
            // customControl11
            // 
            this.customControl11.AnimateBorder = false;
            this.customControl11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(0)))), ((int)(((byte)(34)))), ((int)(((byte)(255)))));
            this.customControl11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.customControl11.Blink = false;
            this.customControl11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.customControl11.BorderStyle = System.Drawing.Drawing2D.DashStyle.Solid;
            this.customControl11.BorderWidth = 0;
            this.customControl11.CenterColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.customControl11.Connector = ShapeControl.ConnecterType.Center;
            this.customControl11.Direction = ShapeControl.LineDirection.None;
            this.customControl11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.customControl11.Location = new System.Drawing.Point(25, 42);
            this.customControl11.Name = "customControl11";
            this.customControl11.Shape = ShapeControl.ShapeType.CustomPolygon;
            this.customControl11.ShapeImage = null;
            this.customControl11.Size = new System.Drawing.Size(87, 83);
            this.customControl11.SurroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.customControl11.TabIndex = 0;
            this.customControl11.Tag2 = "";
            this.customControl11.UseGradient = false;
            this.customControl11.Vibrate = false;
            this.customControl11.Visible = false;
            // 
            // Form4a
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 550);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.customControl11);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form4a";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cognition Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ShapeControl.CustomControl1 customControl11;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}