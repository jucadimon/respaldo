﻿Public Class Form1

 

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        VENTAS()


        GroupBox1.Visible = False

        ENTRANTE.Visible = False



    End Sub


    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

        If CheckBox1.Checked = True Then

            GroupBox1.Visible = True

        Else

            GroupBox1.Visible = False

        End If



    End Sub

    Private Sub VENTAS()

        Try

            Dim A, B, C, D, E, F, G, H, I, J, k, L, N, Ñ, M, O, P, Q, S, T, W, X, Y, Z As Integer

            A = My.Settings.TOTAL_ANILLADO_CARTA - My.Settings.ANILLADO_POLICOVER_CARTA
            Dim vallor_anillado_carta As String = "$  4.000"
            Dim total_valor As Integer = vallor_anillado_carta * My.Settings.ANILLADO_POLICOVER_CARTA
            DataGridView1.Rows.Add("ANILLADO POLICOVER CARTA", vallor_anillado_carta, A, My.Settings.ANILLADO_POLICOVER_CARTA, My.Settings.TOTAL_ANILLADO_CARTA, total_valor)

      
            B = My.Settings.TOTAL_ANILLADO_OFICIO - My.Settings.ANILLADO_POLICOVER_OFICIO
            DataGridView1.Rows.Add("ANILLADO POLICOVER OFICIO", "$  4.000 ", B, My.Settings.ANILLADO_POLICOVER_OFICIO, My.Settings.TOTAL_ANILLADO_OFICIO)


            C = My.Settings.TOTAL_BISTURI - My.Settings.BISTURI
            DataGridView1.Rows.Add("BISTURI", "$  1.500 ", C, My.Settings.BISTURI, My.Settings.TOTAL_BISTURI)


            D = My.Settings.TOTAL_BORRADORES - My.Settings.BOORADORES
            DataGridView1.Rows.Add("BORRADOR", "$  500 ", D, My.Settings.BOORADORES, My.Settings.TOTAL_BORRADORES)


            E = My.Settings.TOTAL_CARTULINA_ENTERA - My.Settings.CARTULINA_ENTERA
            DataGridView1.Rows.Add("CARPETA DE PRESENTACION", "$  500", E, My.Settings.CARFPETA_DE_PRESENTACION, My.Settings.TOTAL_CARPETA_DE_PRESENTACION)


            F = My.Settings.TOTAL_CARPETA_BISCEL_CARTA - My.Settings.CARPETA_BISCEL_CARTA
            DataGridView1.Rows.Add("CARPETA BISCEL CARTA", "$  700", F, My.Settings.CARPETA_BISCEL_CARTA, My.Settings.TOTAL_CARPETA_BISCEL_CARTA)


            G = My.Settings.TOTAL_CARPETA_BISCEL_OFICIO - My.Settings.CARPETA_BISCEL_OFICIO
            DataGridView1.Rows.Add("CARPETA BISCEL OFICIO", "$  800 ", G, My.Settings.CARPETA_BISCEL_OFICIO, My.Settings.TOTAL_CARPETA_BISCEL_OFICIO)


            H = My.Settings.TOTAL_CARTULINA_ENTERA - My.Settings.CARTULINA_ENTERA
            DataGridView1.Rows.Add("CARTULINA ENTERA", "$  1.000 ", H, My.Settings.CARTULINA_ENTERA, My.Settings.TOTAL_CARTULINA_ENTERA)


            I = My.Settings.TOTAL_CARTULINA_ENTERA_NEGRA - My.Settings.CARTULINA_ENTERA_NEGRA
            DataGridView1.Rows.Add("CARTULINA ENTERA NEGRA ", " $  2.000", I, My.Settings.CARTULINA_ENTERA_NEGRA, My.Settings.TOTAL_CARTULINA_ENTERA_NEGRA)


            J = My.Settings.TOTAL_CD - My.Settings.CD
            DataGridView1.Rows.Add("CD", "$  1.000 ", J, My.Settings.CD, My.Settings.TOTAL_CD)


            k = My.Settings.TOTAL_CHINCHE - My.Settings.CHINCHES
            DataGridView1.Rows.Add("CHINCHES", "$  1.000 ", k, My.Settings.CHINCHES, My.Settings.TOTAL_CHINCHE)


            L = My.Settings.TOTAL_CINTA_ENMASCARAR - My.Settings.CINTA_DE_ENMASCARAR
            DataGridView1.Rows.Add("CINTA DE ENMASCARAR", "$  1.600 ", L, My.Settings.CINTA_DE_ENMASCARAR, My.Settings.TOTAL_CINTA_ENMASCARAR)


            N = My.Settings.TOTAL_CINTA_GRANDE - My.Settings.CINTA_GRANDE
            DataGridView1.Rows.Add("CINTA GRANDE", "$  2.000 ", N, My.Settings.CINTA_GRANDE, My.Settings.TOTAL_CINTA_GRANDE)


            Ñ = My.Settings.TOTAL_CINTA_PEQ - My.Settings.CINTA_PEQ
            DataGridView1.Rows.Add("CINTA PEQ", " $  500 ", "38", My.Settings.CINTA_PEQ, My.Settings.TOTAL_CINTA_PEQ)


            M = My.Settings.TOTAL_COLBO_PEQ - My.Settings.COLBON_PEQ
            DataGridView1.Rows.Add("COLBON PEQ", " $ 500 ", M, My.Settings.COLBON_PEQ, My.Settings.TOTAL_COLBO_PEQ)


            O = My.Settings.TOTAL_CORRECTOR - My.Settings.CORRECTOR
            DataGridView1.Rows.Add("CORRECTOR", "$ 1.600 ", O, My.Settings.CORRECTOR, My.Settings.TOTAL_CORRECTOR)


            P = My.Settings.TOTAL_CUADERNO_50H_PEQUEÑO - My.Settings.CUADERNO_50H_PEQUEÑO
            DataGridView1.Rows.Add("CUADERNO 50H PEQ", "$  1.000 ", P, My.Settings.CUADERNO_50H_PEQUEÑO, My.Settings.TOTAL_CUADERNO_50H_PEQUEÑO)


            Q = My.Settings.TOTAL_CUADERNO_ARGOLLADO - My.Settings.CUADERNO_ARGOLLADO
            DataGridView1.Rows.Add("CUADERNO ARGOLLADO", "$  2.500 ", Q, My.Settings.CUADERNO_ARGOLLADO, My.Settings.TOTAL_CUADERNO_ARGOLLADO)


            S = My.Settings.TOTAL_CUADERNO_COCIDO_GRANDE - My.Settings.CUADERNO_COCIDO_GRANDE
            DataGridView1.Rows.Add("CUADERNO COCIDO GRANDE", "$  2.200 ", S, My.Settings.CUADERNO_COCIDO_GRANDE, My.Settings.TOTAL_CUADERNO_COCIDO_GRANDE)


            T = My.Settings.TOTAL_CUADERNO_DE_100_HOJAS - My.Settings.CUADERNO_DE_100_HOJAS
            DataGridView1.Rows.Add("CUADERNO DE 100 HOJAS", "$  1.300 ", T, My.Settings.CUADERNO_DE_100_HOJAS, My.Settings.TOTAL_CUADERNO_DE_100_HOJAS)


            W = My.Settings.TOTAL_CUADERNOS_5_MATERIA - My.Settings.CUADERNOS_5_MATERIA
            DataGridView1.Rows.Add("CUADERNO 5 MATERIAS", "$ 5.000 ", W, My.Settings.CUADERNOS_5_MATERIA, My.Settings.TOTAL_CUADERNOS_5_MATERIA)


            X = My.Settings.TOTAL_LAPICERO - My.Settings.LAPICERO
            DataGridView1.Rows.Add("LAPICERO", "$   800 ", X, My.Settings.LAPICERO, My.Settings.TOTAL_LAPICERO)


            Y = My.Settings.TOTAL_LAPIZ - My.Settings.LAPIZ
            DataGridView1.Rows.Add("LAPIZ", "$ 800 ", Y, My.Settings.LAPIZ, My.Settings.TOTAL_LAPIZ)


            Z = My.Settings.TOTAL_MARCADOR_BORRABLE - My.Settings.MARCADOR_BORRABLE
            DataGridView1.Rows.Add("MARCADOR BORRABLE", "$  1.800 ", Z, My.Settings.MARCADOR_BORRABLE, My.Settings.TOTAL_MARCADOR_BORRABLE)

            Dim papel_periodico, marcador_permamente, mircopunta, minas, octavo_cartulina_florencete, octavo_cartulina As Integer

            marcador_permamente = My.Settings.TOTAL_MARCADOR_PERMANENTE - My.Settings.MARCADOR_PERMANENTE
            DataGridView1.Rows.Add("MARCADOR PERMANENTE", "$ 1.800 ", marcador_permamente, My.Settings.MARCADOR_PERMANENTE, My.Settings.TOTAL_MARCADOR_PERMANENTE)


            mircopunta = My.Settings.TOTAL_MICROPUNTAS - My.Settings.MICROPUNTAS
            DataGridView1.Rows.Add("MICROPUNTAS", " $ 1.500 ", mircopunta, My.Settings.MICROPUNTAS, My.Settings.TOTAL_MICROPUNTAS)


            minas = My.Settings.TOTAL_MINAS - My.Settings.MINAS
            DataGridView1.Rows.Add("MINAS", " $ 1.500 ", minas, My.Settings.MINAS, My.Settings.TOTAL_MINAS)


            octavo_cartulina_florencete = My.Settings.TOTAL_OCATAVOS_DE_CART_FLORECENTE - My.Settings.OCATAVOS_DE_CART_FLORECENTE
            DataGridView1.Rows.Add("OCTAVOS DE CART FLORECENTE ", " $ 500 ", octavo_cartulina_florencete, My.Settings.OCATAVOS_DE_CART_FLORECENTE, My.Settings.TOTAL_OCATAVOS_DE_CART_FLORECENTE)


            octavo_cartulina = My.Settings.TOTAL_OCATOVO_DE_CARTULINAS - My.Settings.OCATOVO_DE_CARTULINAS
            DataGridView1.Rows.Add("OCTAVOS DE CARTULINAS", "$ 400 ", octavo_cartulina, My.Settings.OCATOVO_DE_CARTULINAS, My.Settings.TOTAL_OCATOVO_DE_CARTULINAS)


            papel_periodico = My.Settings.TOTAL_PAPEL_PERIODICO - My.Settings.PAPEL_PERIODICO
            DataGridView1.Rows.Add("PAPEL PERIODICO", "$ 300 ", papel_periodico, My.Settings.PAPEL_PERIODICO, My.Settings.TOTAL_PAPEL_PERIODICO)


            Dim reglas As Integer = My.Settings.TOTAL_REGLAS - My.Settings.REGLAS
            DataGridView1.Rows.Add("REGLAS", "$ 800 ", reglas, My.Settings.REGLAS, My.Settings.TOTAL_REGLAS)


            Dim resaltador As Integer = My.Settings.TOTAL_REGLAS - My.Settings.REGLAS
            DataGridView1.Rows.Add("RESALTADOR", "$ 1.500 ", "14", My.Settings.RESALTADOR)


            Dim sacapunta As Integer = My.Settings.TOTAL_SACAPUNTAS_METALICO - My.Settings.SACAPUNTAS_METALICO
            DataGridView1.Rows.Add("SACAPUNTAS METALICO", "$ 500 ", sacapunta, My.Settings.SACAPUNTAS_METALICO, My.Settings.TOTAL_SACAPUNTAS_METALICO)


            Dim sharpier As Integer = My.Settings.TOTAL_SHARPIER - My.Settings.SHARPIER
            DataGridView1.Rows.Add("SHARPIER", "$ 2.500 ", sharpier, My.Settings.SHARPIER, sharpier)


            Dim sobre_carta As Integer = My.Settings.TOTAL_SOBRE_DE_MANILA_CARTA - My.Settings.SOBRE_DE_MANILA_CARTA
            DataGridView1.Rows.Add("SOBRE DE MANILA CARTA", "$ 400 ", sobre_carta, My.Settings.SOBRE_DE_MANILA_CARTA, My.Settings.TOTAL_SOBRE_DE_MANILA_CARTA)


            Dim sobre_oficio As Integer = My.Settings.TOTAL_SOBRE_DE_MANILA_OFICIO - My.Settings.SOBRE_DE_MANILA_OFICIO
            DataGridView1.Rows.Add("SOBRE DE MANILA OFICIO", "$ 400 ", sobre_oficio, My.Settings.SOBRE_DE_MANILA_OFICIO, My.Settings.TOTAL_SOBRE_DE_MANILA_OFICIO)


            Dim tabla_periodica As Integer = My.Settings.TOTAL_TABLA_DE_PRIODICA_GRANDE - My.Settings.TABLA_DE_PRIODICA_GRANDE
            DataGridView1.Rows.Add("TABLA PERIODICA GRANDE", "$ 1.500 ", tabla_periodica, My.Settings.TABLA_DE_PRIODICA_GRANDE, My.Settings.TOTAL_TABLA_DE_PRIODICA_GRANDE)


            Dim tijera As Integer = My.Settings.TOTAL_TIJERAS_PUNTA_ROMA - My.Settings.TIJERAS_PUNTA_ROMA
            DataGridView1.Rows.Add("TIJERAS PUNTA ROMA", "$ 1.000 ", tijera, My.Settings.TIJERAS_PUNTA_ROMA, My.Settings.TOTAL_TIJERAS_PUNTA_ROMA)



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click



        If ComboBox1.Text = "ANILLADO POLICOVER CARTA" Then

            Dim f As Integer

            f = My.Settings.ANILLADO_POLICOVER_CARTA

            If f >= 0 Then

                ListBox1.Text = ANILLADO_POLICOVER_CARTA



            Else

                My.Settings.ANILLADO_POLICOVER_CARTA = My.Settings.ANILLADO_POLICOVER_CARTA + TextBox2.Text

                My.Settings.Save()

                DataGridView1.Rows.Clear()

                Call VENTAS()

            End If

        End If


        If ComboBox1.Text = "ANILLADO POLICOVER OFICIO" Then

            My.Settings.ANILLADO_POLICOVER_OFICIO = My.Settings.ANILLADO_POLICOVER_OFICIO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "BISTURI" Then

            My.Settings.BISTURI = My.Settings.BISTURI + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "BOORADORES" Then

            My.Settings.BOORADORES = My.Settings.BOORADORES + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()


        End If


        If ComboBox1.Text = "CARFPETA DE PRESENTACION" Then

            My.Settings.CARFPETA_DE_PRESENTACION = My.Settings.CARFPETA_DE_PRESENTACION + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CARPETA BISCEL CARTA" Then

            My.Settings.CARPETA_BISCEL_CARTA = My.Settings.CARPETA_BISCEL_CARTA + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CARPETA BISCEL OFICIO" Then

            My.Settings.CARPETA_BISCEL_OFICIO = My.Settings.CARPETA_BISCEL_OFICIO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CARTULINA ENTERA" Then

            My.Settings.CARTULINA_ENTERA = My.Settings.CARTULINA_ENTERA + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()


        End If


        If ComboBox1.Text = "CARTULINA ENTERA NEGRA" Then

            My.Settings.CARTULINA_ENTERA_NEGRA = My.Settings.CARTULINA_ENTERA_NEGRA + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CD" Then

            My.Settings.CD = My.Settings.CD + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CHINCHES" Then

            My.Settings.CHINCHES = My.Settings.CHINCHES + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CINTA DE ENMASCARAR" Then

            My.Settings.CINTA_DE_ENMASCARAR = My.Settings.CINTA_DE_ENMASCARAR + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CINTA GRNADE" Then

            My.Settings.CINTA_GRANDE = My.Settings.CINTA_GRANDE + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CINTA PEQ." Then

            My.Settings.CINTA_PEQ = My.Settings.CINTA_PEQ + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "COLBON PEQ." Then

            My.Settings.COLBON_PEQ = My.Settings.COLBON_PEQ + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CORRECTOR" Then

            My.Settings.CORRECTOR = My.Settings.CORRECTOR + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CUADERNO 50H PEQUEÑO" Then

            My.Settings.CUADERNO_50H_PEQUEÑO = My.Settings.CUADERNO_50H_PEQUEÑO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CUADERNO ARGOLLADO" Then

            My.Settings.CUADERNO_ARGOLLADO = My.Settings.CUADERNO_ARGOLLADO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CUADERNO COCIDO GRANDE" Then

            My.Settings.CUADERNO_COCIDO_GRANDE = My.Settings.CUADERNO_COCIDO_GRANDE + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CUADERNO DE 100 HOJAS" Then

            My.Settings.CUADERNO_DE_100_HOJAS = My.Settings.CUADERNO_DE_100_HOJAS + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "CUADERNOS 5 MATERIA" Then

            My.Settings.CUADERNOS_5_MATERIA = My.Settings.CUADERNOS_5_MATERIA + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "LAPICERO" Then

            My.Settings.LAPICERO = My.Settings.LAPICERO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "LAPIZ" Then

            My.Settings.LAPIZ = My.Settings.LAPIZ + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "MARCADOR BORRABLE" Then

            My.Settings.MARCADOR_BORRABLE = My.Settings.MARCADOR_BORRABLE + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "MARCADOR PERMANENTE" Then

            My.Settings.MARCADOR_PERMANENTE = My.Settings.MARCADOR_PERMANENTE + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "MICROPUNTAS" Then

            My.Settings.MICROPUNTAS = My.Settings.MICROPUNTAS + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "MINAS" Then

            My.Settings.MINAS = My.Settings.MINAS + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "OCATAVOS DE CART.FLORECENTE" Then

            My.Settings.OCATAVOS_DE_CART_FLORECENTE = My.Settings.OCATAVOS_DE_CART_FLORECENTE + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "OCATOVO DE CARTULINAS" Then

            My.Settings.OCATOVO_DE_CARTULINAS = My.Settings.OCATOVO_DE_CARTULINAS + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "PAPEL PERIODICO" Then

            My.Settings.PAPEL_PERIODICO = My.Settings.PAPEL_PERIODICO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "REGLAS" Then

            My.Settings.REGLAS = My.Settings.REGLAS + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "RESALTADOR" Then

            My.Settings.RESALTADOR = My.Settings.RESALTADOR + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "SACAPUNTAS METALICO" Then

            My.Settings.SACAPUNTAS_METALICO = My.Settings.SACAPUNTAS_METALICO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "SHARPIER" Then

            My.Settings.SHARPIER = My.Settings.SHARPIER + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "SOBRE DE MANILA CARTA" Then

            My.Settings.SOBRE_DE_MANILA_CARTA = My.Settings.SOBRE_DE_MANILA_CARTA + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "SOBRE DE MANILA OFICIO " Then

            My.Settings.SOBRE_DE_MANILA_OFICIO = My.Settings.SOBRE_DE_MANILA_OFICIO + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "TABLA DE PRIODICA GRANDE" Then

            My.Settings.TABLA_DE_PRIODICA_GRANDE = My.Settings.TABLA_DE_PRIODICA_GRANDE + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox1.Text = "TIJERAS PUNTA ROMA" Then

            My.Settings.TIJERAS_PUNTA_ROMA = My.Settings.TIJERAS_PUNTA_ROMA + TextBox2.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If



    End Sub


    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

        Dim r As String

        If CheckBox2.Checked = True Then

            r = InputBox("PARA PODER SUMINISTRAR PRODUCTO AL SOFTWARE POR PAVOR INGRESAR LA CONTRASEÑA QUE LE ASIGNO EL PROGRAMADOR", "INGRESAR CONTRASEÑA")

            If r = "copyfaxcolombia" Then


                ENTRANTE.Visible = True

            Else


                ENTRANTE.Visible = False

                CheckBox2.Checked = False

                MsgBox("SOLO EL ADMINISTRADOR PUEDE SUMINISTRAR", MsgBoxStyle.Information, "SOLO ADMINISTRADOR")

            End If


        Else


            ENTRANTE.Visible = False

            CheckBox2.Checked = False

        End If


    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click


        If ComboBox2.Text = "ANILLADO POLICOVER CARTA" Then

            My.Settings.TOTAL_ANILLADO_CARTA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "ANILLADO POLICOVER OFICIO" Then

            My.Settings.TOTAL_ANILLADO_OFICIO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "BISTURI" Then

            My.Settings.TOTAL_BISTURI = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "BORRADOR" Then

            My.Settings.TOTAL_BORRADORES = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CARPETA_DE_PRESENTACION" Then

            My.Settings.TOTAL_CARPETA_DE_PRESENTACION = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()


        End If


        If ComboBox2.Text = "CARPETA BISCEL CARTA" Then

            My.Settings.TOTAL_CARPETA_BISCEL_CARTA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CARPETA BISCEL OFICIO" Then

            My.Settings.TOTAL_CARPETA_BISCEL_OFICIO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CARTULINA ENTERA" Then

            My.Settings.TOTAL_CARTULINA_ENTERA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CARTULINA ENTERA NEGRA" Then

            My.Settings.TOTAL_CARTULINA_ENTERA_NEGRA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CD" Then

            My.Settings.TOTAL_CD = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CHINCHES" Then

            My.Settings.TOTAL_CHINCHE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CINTA DE ENMASCARAR" Then

            My.Settings.TOTAL_CINTA_ENMASCARAR = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CINTA GRNADE" Then

            My.Settings.TOTAL_CINTA_GRANDE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()


        End If


        If ComboBox2.Text = "CINTA PEQ." Then

            My.Settings.TOTAL_CINTA_PEQ = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "COLBON PEQ." Then

            My.Settings.TOTAL_COLBO_PEQ = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CORRECTOR" Then

            My.Settings.TOTAL_CORRECTOR = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CUADERNO 50H PEQUEÑO" Then

            My.Settings.TOTAL_CUADERNO_50H_PEQUEÑO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CUADERNO ARGOLLADO" Then

            My.Settings.TOTAL_CUADERNO_ARGOLLADO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CUADERNO COCIDO GRANDE" Then

            My.Settings.CUADERNO_COCIDO_GRANDE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CUADERNO DE 100 HOJAS" Then

            My.Settings.TOTAL_CUADERNO_DE_100_HOJAS = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "CUADERNOS 5 MATERIA" Then

            My.Settings.TOTAL_CUADERNOS_5_MATERIA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "LAPICERO" Then

            My.Settings.TOTAL_LAPICERO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "LAPIZ" Then

            My.Settings.TOTAL_LAPIZ = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "MARCADOR BORRABLE" Then

            My.Settings.TOTAL_MARCADOR_BORRABLE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "MARCADOR PERMANENTE" Then

            My.Settings.TOTAL_MARCADOR_PERMANENTE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "MICROPUNTAS" Then

            My.Settings.TOTAL_MICROPUNTAS = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "MINAS" Then

            My.Settings.TOTAL_MINAS = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "OCATAVOS DE CART.FLORECENTE" Then

            My.Settings.TOTAL_OCATAVOS_DE_CART_FLORECENTE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "OCATOVO DE CARTULINAS" Then

            My.Settings.TOTAL_OCATOVO_DE_CARTULINAS = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "PAPEL PERIODICO" Then

            My.Settings.TOTAL_PAPEL_PERIODICO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "REGLAS" Then

            My.Settings.TOTAL_REGLAS = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "RESALTADOR" Then

            My.Settings.TOTAL_RESALTADOR = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "SACAPUNTAS METALICO" Then

            My.Settings.TOTAL_SACAPUNTAS_METALICO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "SHARPIER" Then

            My.Settings.TOTAL_SHARPIER = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "SOBRE DE MANILA CARTA" Then

            My.Settings.TOTAL_SOBRE_DE_MANILA_CARTA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "SOBRE DE MANILA OFICIO " Then

            My.Settings.TOTAL_SOBRE_DE_MANILA_OFICIO = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "TABLA DE PRIODICA GRANDE" Then

            My.Settings.TOTAL_TABLA_DE_PRIODICA_GRANDE = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If


        If ComboBox2.Text = "TIJERAS PUNTA ROMA" Then

            My.Settings.TOTAL_TIJERAS_PUNTA_ROMA = TextBox3.Text

            My.Settings.Save()

            DataGridView1.Rows.Clear()

            Call VENTAS()

        End If



    End Sub





    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked

        MsgBox("ES PROGRAMAR FUE ESCRITO DISEÑADO Y ELABORADO POR                                KEY STIVEN LOPEZ HURTADO", MsgBoxStyle.Information, "ACERCA....DE")

    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked

        MsgBox("ESTE PROGRAMA ESTA DISEÑADO PARA LLEVAR UN CONTROL DEL INVENTARIO DE LA PAPELERIA EL CUADRO DE CONFIRMACION QUE DICE SUMISTRAR SIRVE PARA PODER AGREGAR CANTIDA NUEVA A UN PRODUCTO EL CUAL SOLO PUEDE HACER EL ADMINISTRADOR Y EL OTRO CUADRO DE CONFIRMACION QUE DICE VENTAS DEL DIA PARA QUE LE USUSARIO QUE ESTA ACARGO PUEDO LLENAR LA BASE DE DATO CON LA CANTIDA DE PRODUCTO VENDIDA EN EL DIA", MsgBoxStyle.Information, "BREVE DOCUMENTACION")

    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged

        Dim r As String

        If CheckBox3.Checked = True Then

            r = InputBox("PARA PODER SUMINISTRAR PRODUCTO AL SOFTWARE POR PAVOR INGRESAR LA CONTRASEÑA QUE LE ASIGNO EL PROGRAMADOR", "INGRESAR CONTRASEÑA")

            If r = "copyfaxcolombia" Then

                My.Settings.ANILLADO_POLICOVER_CARTA = 0
                My.Settings.ANILLADO_POLICOVER_OFICIO = 0
                My.Settings.BISTURI = 0
                My.Settings.BOORADORES = 0
                My.Settings.CARFPETA_DE_PRESENTACION = 0
                My.Settings.CARPETA_BISCEL_CARTA = 0
                My.Settings.CARPETA_BISCEL_OFICIO = 0
                My.Settings.CARTULINA_ENTERA = 0
                My.Settings.CARTULINA_ENTERA_NEGRA = 0
                My.Settings.CD = 0
                My.Settings.CHINCHES = 0
                My.Settings.CINTA_DE_ENMASCARAR = 0
                My.Settings.CINTA_GRANDE = 0
                My.Settings.CINTA_PEQ = 0
                My.Settings.COLBON_PEQ = 0
                My.Settings.CORRECTOR = 0
                My.Settings.CUADERNO_50H_PEQUEÑO = 0
                My.Settings.CUADERNO_ARGOLLADO = 0
                My.Settings.CUADERNO_COCIDO_GRANDE = 0
                My.Settings.CUADERNO_DE_100_HOJAS = 0
                My.Settings.CUADERNOS_5_MATERIA = 0
                My.Settings.LAPICERO = 0
                My.Settings.LAPIZ = 0
                My.Settings.MARCADOR_BORRABLE = 0
                My.Settings.MARCADOR_PERMANENTE = 0
                My.Settings.MICROPUNTAS = 0
                My.Settings.MINAS = 0
                My.Settings.OCATAVOS_DE_CART_FLORECENTE = 0
                My.Settings.OCATOVO_DE_CARTULINAS = 0
                My.Settings.PAPEL_PERIODICO = 0
                My.Settings.REGLAS = 0
                My.Settings.RESALTADOR = 0
                My.Settings.SACAPUNTAS_METALICO = 0
                My.Settings.SHARPIER = 0
                My.Settings.SOBRE_DE_MANILA_CARTA = 0
                My.Settings.SOBRE_DE_MANILA_OFICIO = 0
                My.Settings.TABLA_DE_PRIODICA_GRANDE = 0
                My.Settings.TIJERAS_PUNTA_ROMA = 0

                My.Settings.TOTAL_ANILLADO_CARTA = 0
                My.Settings.TOTAL_ANILLADO_OFICIO = 0
                My.Settings.TOTAL_BISTURI = 0
                My.Settings.TOTAL_BORRADORES = 0
                My.Settings.TOTAL_CARPETA_DE_PRESENTACION = 0
                My.Settings.TOTAL_CARPETA_BISCEL_CARTA = 0
                My.Settings.TOTAL_CARPETA_BISCEL_OFICIO = 0
                My.Settings.TOTAL_CARTULINA_ENTERA = 0
                My.Settings.TOTAL_CARTULINA_ENTERA_NEGRA = 0
                My.Settings.TOTAL_CD = 0
                My.Settings.TOTAL_CHINCHE = 0
                My.Settings.TOTAL_CINTA_ENMASCARAR = 0
                My.Settings.TOTAL_CINTA_GRANDE = 0
                My.Settings.TOTAL_CINTA_PEQ = 0
                My.Settings.TOTAL_COLBO_PEQ = 0
                My.Settings.TOTAL_CORRECTOR = 0
                My.Settings.TOTAL_CUADERNO_50H_PEQUEÑO = 0
                My.Settings.TOTAL_CUADERNO_ARGOLLADO = 0
                My.Settings.TOTAL_CUADERNO_COCIDO_GRANDE = 0
                My.Settings.TOTAL_CUADERNO_DE_100_HOJAS = 0
                My.Settings.TOTAL_CUADERNOS_5_MATERIA = 0
                My.Settings.TOTAL_LAPICERO = 0
                My.Settings.TOTAL_LAPIZ = 0
                My.Settings.TOTAL_MARCADOR_BORRABLE = 0
                My.Settings.TOTAL_MARCADOR_PERMANENTE = 0
                My.Settings.TOTAL_MICROPUNTAS = 0
                My.Settings.TOTAL_MINAS = 0
                My.Settings.TOTAL_OCATAVOS_DE_CART_FLORECENTE = 0
                My.Settings.TOTAL_OCATOVO_DE_CARTULINAS = 0
                My.Settings.TOTAL_PAPEL_PERIODICO = 0
                My.Settings.TOTAL_REGLAS = 0
                My.Settings.TOTAL_RESALTADOR = 0
                My.Settings.TOTAL_SACAPUNTAS_METALICO = 0
                My.Settings.TOTAL_SHARPIER = 0
                My.Settings.TOTAL_SOBRE_DE_MANILA_CARTA = 0
                My.Settings.TOTAL_SOBRE_DE_MANILA_OFICIO = 0
                My.Settings.TOTAL_TABLA_DE_PRIODICA_GRANDE = 0
                My.Settings.TOTAL_TIJERAS_PUNTA_ROMA = 0

                My.Settings.Save()

                DataGridView1.Rows.Clear()

                VENTAS()

                CheckBox3.Checked = False

            Else

                CheckBox3.Checked = False

                MsgBox("SOLO EL ADMINISTRADOR PUEDE HACER RESET", MsgBoxStyle.Information, "SOLO ADMINISTRADOR")

            End If


        Else




            CheckBox3.Checked = False

        End If
    End Sub
End Class
