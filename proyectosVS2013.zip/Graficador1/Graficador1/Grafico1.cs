﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace Graficador1
{
    class Grafico1 //Cartesiano
    {
        int x, y, ancho, alto, centrox, centroy;
        public Graphics grafico;
        Pen lapiz = new Pen(Color.Black, 0.9f);

        public void set_x(int valor)
        {
            x = valor;
        }
        public void set_y(int valor)
        {
            y = valor;
        }
        public void DibujarPlanoCartesiano(PictureBox pbox)
        {
            int centroX = pbox.Width / 2, centroY = pbox.Height / 2;
            Bitmap bmp = new Bitmap(pbox.Width, pbox.Height);
            grafico = Graphics.FromImage(bmp); //Desde un picturebox existente
            grafico.Clear(Color.Transparent);
            grafico.SmoothingMode = SmoothingMode.HighQuality;
            grafico.TranslateTransform(centroX, centroY);
            grafico.ScaleTransform(1, -1);
            grafico.DrawLine(lapiz, centroX * -1, 0, centroX * 2, 0);//dibujamos eje x
            grafico.DrawLine(lapiz, 0, centroY, 0, centroY * -1);//dibujamos eje y
            //subdivisiones de los ejes:
            for (int i = -centroX; i < centroX; i += 8)
            {
                //divisiones para el ejeY
                grafico.DrawLine(lapiz, 5, i, -5, i);//linea horizontal
                //divisiones para el ejeX
                grafico.DrawLine(lapiz, i, 5, i, -5);//linea vertical
            }
            pbox.Image = bmp;
        }
    }
}
