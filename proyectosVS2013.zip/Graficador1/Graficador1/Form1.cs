﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;


namespace Graficador1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Grafico1 cartesiano = new Grafico1();
        private void button1_Click(object sender, EventArgs e)
        {
            cartesiano.DibujarPlanoCartesiano(this.pictureBox1);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string nombre = textBox1.Text.ToString();
            string directorio1 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) +
                "\\grafico_cartesiano_" + nombre + ".png";
            var mm = (Bitmap)pictureBox1.Image.Clone();
            mm.Save(directorio1, ImageFormat.Png);
        }
    }
}
