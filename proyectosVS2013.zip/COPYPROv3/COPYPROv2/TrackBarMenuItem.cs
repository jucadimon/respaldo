﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace COPYPROv2
{
    [ToolStripItemDesignerAvailability(ToolStripItemDesignerAvailability.MenuStrip |
    ToolStripItemDesignerAvailability.ContextMenuStrip)]
    public class TrackBarMenuItem : ToolStripControlHost
    {
        private TrackBar trackBar;

        public TrackBarMenuItem()
            : base(new TrackBar())
        {
            this.trackBar = this.Control as TrackBar;
            this.trackBar.BackColor = System.Drawing.Color.SteelBlue;
        }
        // agregar propiedades, eventos etc.
    }
}
