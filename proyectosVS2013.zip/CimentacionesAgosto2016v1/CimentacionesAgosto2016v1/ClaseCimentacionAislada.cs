﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CimentacionesAgosto2016v1
{
    class ClaseCimentacionAislada
    {
        // VARIABLES DE ENTRADA (unidades del SI: MPa, m, KN, m2, m3, KN/m3)
        private readonly string nombre, tipoCimentacion; //tipo: cuadrada, rectangular
        private readonly double PD, PL, T, alfa, FC, a, b;
        private readonly double fc, fy, TM, df, rsuelo, EsfuerzoAdmisible; //FY=420
        private readonly double rconcreto, ficortante, landa; //rconcreto=24, ficortante=0.75, landa=1
        private readonly double rprima, d1; //rprima = 0.075, d1 = 0.15
        // variables del presupuesto
        const double cexc = 22292, cacero = 12952, ccon = 82171, czap = 55419, con3000 = 260200, 
            A420 = 2800, Hmenor = 500, mezcladora = 8500, vibrador = 5000;

        // VARIABLES DE SALIDA (unidades del SI: MPa, m, KN, m2, m3, KN/m3)
        double P1, P1u;
        double r, Hmin, ldc, ldc1, ldc2, d2, d3, d, H;
        double Sobrecarga, EsfuerzoNeto, B, L, areareq, areafinal; //B=1, L=1 iniciales

        double V1, V2, rel1, rel2, voladizomax, relmax;
        double Esfuerzo1u, AtL, V1u, fiVc;
        double AtB, V2u, fiVc2, bo, betac, fiVc1p, fiVc2p, fiVc3p, fiVcpmin, Atp, V1up;
        double kL, mL, MuL, cuantiadL, AtLf, brazoL;
        double AsrL, AstL, AssL, NbL, SccL, SlbL, Sminb;
        double AssrL, cuantiaLsum, lddL, cc1, cc2, cc, relccdbz, factorAsL, ldrL, lcorteL;

        double AtBf, brazoB, MuB, kB, mB, cuantiadB, AsrB, AstB, AssB, NbB, SccB, SlbB, AssrB;
        double cuantiaBsum, lddB, factorAsB, ldrB, lcorteB;

        double vconcreto, vexcavacion, acerototal, costo; //costo = 0

        public ClaseCimentacionAislada(string ID, string tipo, double CargaMuerta, double CargaViva, 
            double AnchoColumna, double LargoColumna, double EsfuerzoConcreto, double TamanoMaximoAgregado,
            double ProfundidadDesplante, double rSuelo, double EsfuerzoAdmisibleSuelo, double rConcreto,
            double RecubrimientoAcero)
        {
            nombre = ID;
            tipoCimentacion = tipo;
            PD = CargaMuerta;
            PL = CargaViva;
            a = AnchoColumna;
            b = LargoColumna;
            fc = EsfuerzoConcreto;
            TM = TamanoMaximoAgregado;
            df = ProfundidadDesplante;
            rsuelo = rSuelo;
            EsfuerzoAdmisible = EsfuerzoAdmisibleSuelo;
            rconcreto = rConcreto;
            rprima = RecubrimientoAcero;
        }
        public string Nombre { get { return nombre; } }
        public string _tipoCimentacion { get { return tipoCimentacion; } }
        public double _PD { get { return PD; } }
        public double _PL { get { return PL; } }
        public double _a { get { return a; } }
        public double _b { get { return b; } }
        public double _fc { get { return fc; } }
        public double _TM { get { return TM; } }
        public double _df { get { return df; } }
        public double _rsuelo { get { return rsuelo; } }
        public double _EsfuerzoAdmisible { get { return EsfuerzoAdmisible; } }
        public double _rconcreto { get { return rconcreto; } }
        public double _rprima { get { return rprima; } }

        // Calculo de las cargas de diseño (P1, P1u)
        // detalles constructivos y tipo de concreto (fc, rconcreto)
        // tamaño maximo del agregado (TM)
        // estribos N4@10cm para el acero de la columna (FC)
        // escogemos las dimensiones de la columna (a,b)
        // escogemos la posicion de la columna (T, alfa)
        // escogemos el diametro de las barras ( diametrobz, Areabz, Masabz, Ddoblamientoz, rprima )
        // bloque de la barra de zapata
        // bloque de la barra de columna
        // propiedades del suelo de excavacion (rsuelo, df, EsfuerzoAdmisible)
        // calculamos el espesor del cimiento (r, Hmin, ldc, ldc1, ldc2, d2, d3, d, H)
        // calculamos el esfuerzo neto con el H encontrado y el area requerida 
        // ( Sobrecarga, EsfuerzoNeto, B, L, areareq, areafinal )
        // calculamos las dimensiones ( OPCION TIPO DE CIMENTACION: "tipo" cuadrada, rectangular)
        // calculos de rigidez:
        // -calculamos los voladizos y calculamos las relaciones(V1, V2, rel1, rel2, voladizomax, relmax)
        // los condicionales para rediseñar -OJO-
        // calculamos la presion de contacto mayorada (Esfuerzo1u, AtL, V1u, fiVc;)
        // accion como viga (Esfuerzo1u, AtL, V1u, fiVc;)
        // accion como viga en el otro sentido (AtB, V2u, fiVc2, bo, betac, fiVc1p, fiVc2p, fiVc3p, fiVcpmin, Atp, V1up;)
        // accion punzonamiento
        // Diseño a flexion
        // refuerzo paralelo a L (AsrL, AstL, AssL, NbL, SccL, SlbL, Sminb)
        // longitud de corte de las barras
        // diseño a flexion refuerzo paralelo a B (AtBf, brazoB, MuB, kB, mB, cuantiadB, AsrB, AstB, AssB, NbB, SccB, SlbB, AssrB)
        // longitud de corte de las barras
        // calculo de las cantidades de obra
        // presupuesto

        // metodo zapata cuadrada
        // metodo zapata Rectangular
        // metodo para calcular la cuantia de acero
        // creamos el metodo que calcula el presupuesto y recibe tres parametros que son las cantidades de materiales
        // metodo biseccion (hallar raices de polinomios)
    }
}
